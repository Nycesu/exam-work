import sqlite3 

connection = sqlite3.connect("movies.db")

cursor = connection.cursor()

movies_list = [("The Dark Knight", "Christopher Nolan", 2008), ("Pulp Fiction", "Quentin Taratino", 1994), ("Spirited Away", "Hayao Miyazaki", 2001), ("Iron Man", "Jon Favreau", 2008)]

cursor.executemany("INSERT INTO Movies VALUES (?,?,?)", movies_list)

cursor.execute("SELECT * FROM Movies")

print(cursor.fetchall())

connection.commit()
connection.close()
